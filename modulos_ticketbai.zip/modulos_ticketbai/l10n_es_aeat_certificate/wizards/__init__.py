# -*- coding: utf-8 -*-
# (c) 2017 Diagram Software S.L.
# Copyright 2017 Ignacio Ibeas <ignacio@acysos.com>
# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import aeat_certificate_password
