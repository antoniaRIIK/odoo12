To use this module, you need to:

#. Go to Accounting (or Invoicing) > Sales > Customer Invoices.
#. Create a new invoice.
#. Insert a new invoice line without taxes.
#. Press on "Validate".
#. An error will raise preventing to do it.
