En el momento de la instalación, se auto-configuran las secuencias de facturas
de todos los diarios de todas las compañías españolas existentes, poniendo la
secuencia que había anteriormente en el campo "Secuencia de asiento", y
creándose una nueva secuencia única por compañía para ese campo.
